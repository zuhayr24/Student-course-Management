package com.example.StudentCrud.controller;

import com.example.StudentCrud.domain.Login;
import com.example.StudentCrud.domain.Student;
import com.example.StudentCrud.service.Loginservice;
import com.example.StudentCrud.service.StudentService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.Objects;

@Controller
public class Logincontroller {

    @Autowired
    private Loginservice userService;

    @Autowired
    private StudentService studentService; // To fetch students data

    // Show login page
    @GetMapping("/login")
    public ModelAndView login() {
        ModelAndView mav = new ModelAndView("login");
        mav.addObject("user", new Login());  // Adding empty Login object to the model
        return mav;
    }

    // Handle login logic
    @PostMapping("/login")
    public String login(@ModelAttribute("user") Login user, Model model) {

        // Authenticate user by username and password
        Login oauthUser = userService.login(user.getUsername(), user.getPassword());

        // If user is authenticated, redirect to the home page
        if (Objects.nonNull(oauthUser)) {
            // Fetch all student data and pass to the view
            List<Student> liststudent = studentService.listAll();
            model.addAttribute("liststudent", liststudent);
            return "index";  // Return the homepage with student data
        } else {
            // Invalid credentials, stay on the login page
            model.addAttribute("error", "Invalid username or password!");  // Optional: display error message
            return "login";  // Stay on login page
        }
    }

    // Handle logout
    @RequestMapping(value = {"/logout"}, method = RequestMethod.POST)
    public String logoutDo(HttpServletRequest request, HttpServletResponse response) {
        // Clear session and logout logic if needed (handled automatically in Spring)
        return "redirect:/login";  // Redirect to login page after logout
    }
}

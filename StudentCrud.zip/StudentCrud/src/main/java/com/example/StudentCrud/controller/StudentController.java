package com.example.StudentCrud.controller;

import com.example.StudentCrud.domain.Student;
import com.example.StudentCrud.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class StudentController {

    @Autowired
    private StudentService service;  // This is correctly injected

    // This method is no longer used for fetching students after login
    @GetMapping("/studentHome")
    public String viewHomePage(Model model) {
        List<Student> liststudent = service.listAll();
        model.addAttribute("liststudent", liststudent);
        return "index";
    }

    @GetMapping("/new")
    public String add(Model model) {
        model.addAttribute("student", new Student());
        return "new";
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveStudent(@ModelAttribute("student") Student std) {
        service.save(std);  // Using the injected service to save the student
        return "redirect:/studentHome";  // Redirect to studentHome
    }

    @RequestMapping("/edit/{id}")
    public ModelAndView showEditStudentPage(@PathVariable(name = "id") int id) {
        ModelAndView mav = new ModelAndView("new");
        Student std = service.get(id);
        mav.addObject("student", std);
        return mav;
    }

    @RequestMapping("/delete/{id}")
    public String deletestudent(@PathVariable(name = "id") int id) {
        service.delete(id);
        return "redirect:/studentHome";  // Redirect to studentHome
    }

    @GetMapping("/students")
    public String getAllStudents(@RequestParam(value = "sort", defaultValue = "asc") String sort, Model model) {
        List<Student> liststudent = "desc".equals(sort) ? service.getAllStudentsSortedByFeeDesc() : service.getAllStudentsSortedByFeeAsc();
        model.addAttribute("liststudent", liststudent);
        return "index";
    }


    @GetMapping("/index")
    public String showIndexPage(Model model) {
        List<Student> liststudent = service.listAll();  // Fetch all students from the service
        model.addAttribute("liststudent", liststudent);  // Add the list of students to the model
        return "index";  // This will render the index.html page and display the student data
    }

}
